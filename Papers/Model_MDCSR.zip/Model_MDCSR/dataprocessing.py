import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.init as init
import pickle
from scipy.sparse import csr_matrix
from scipy.sparse import coo_matrix
from tqdm import tqdm
import math
from torch.utils.data import Dataset,DataLoader
from random import choice     # 随机抽取一个元素
from random import sample     # 随机抽取若干个无重复元素
import concurrent.futures
import torch.nn.functional as F

#将所有交互数据编码为向量
def user_item_interaction():
    # 构建movie-user交互矩阵
    df_mov = pd.read_csv('../data/records/movies.csv')
    users_mov = df_mov['UserID'].max() + 1
    items_mov = df_mov['itemID'].max() + 1
    #print(users_mov, items_mov)
    occurences_mov = csr_matrix((users_mov, items_mov), dtype='int8')
    def set_occurences_mov(user, item):
        occurences_mov[user, item] = 1
    df_mov.apply(lambda row: set_occurences_mov(row['UserID'], row['itemID']), axis=1)

    # 构建book-user交互矩阵
    df_bok = pd.read_csv('../data/records/books.csv')
    users_bok = df_bok['UserID'].max() + 1
    items_bok = df_bok['itemID'].max() + 1
    occurences_bok = csr_matrix((users_bok, items_bok), dtype='int8')
    def set_occurences_bok(user, item):
        occurences_bok[user, item] = 1
    df_bok.apply(lambda row: set_occurences_bok(row['UserID'], row['itemID']), axis=1)

    # 构建music-user交互矩阵
    df_msc = pd.read_csv('../data/records/musics.csv')
    users_msc = df_msc['UserID'].max() + 1
    items_msc = df_msc['itemID'].max() + 1
    occurences_msc = csr_matrix((users_msc, items_msc), dtype='int8')
    def set_occurences_msc(user, item):
        occurences_msc[user, item] = 1
    df_msc.apply(lambda row: set_occurences_msc(row['UserID'], row['itemID']), axis=1)
    # movie-user、book-user、music-user交互矩阵:
    return occurences_mov, occurences_bok, occurences_msc

#将user编码为one-hot向量
def user_to_onehot():
    df = pd.read_csv('../data/records/user.csv', sep='\n')
    df_user = df['UserID']
    data_user = df_user.values.astype(int)
    with open('../data/records/' + 'user_index.pkl', 'wb') as f_t:
        pickle.dump(data_user, f_t, pickle.HIGHEST_PROTOCOL)
    return data_user

def update(t1, t2, dropna=False):
    return t1.map(t2).dropna() if dropna else t1.map(t2).fillna(t1)




# 将movie领域item编码为multi-hot向量
def mov_fea_value():
    df = pd.read_csv('../data/movie/movie.csv', sep='|')
    df_mov = pd.read_csv('../data/movie/movie_feature_id.csv', sep=',')
    df1 = df.drop(['itemID'], axis=1)
    df1['director'] = df1['director'].str.strip()
    update_d = update(df1.director, df_mov.set_index('itemID').itemIdx)
    df1['director'] = update_d
    df1['writer1'] = df1['writer1'].str.strip()
    update_w1 = update(df1.writer1, df_mov.set_index('itemID').itemIdx)
    df1['writer1'] = update_w1
    df1['writer2'] = df1['writer2'].str.strip()
    update_w2 = update(df1.writer2, df_mov.set_index('itemID').itemIdx)
    df1['writer2'] = update_w2
    df1['actor1'].astype(str)
    df1['actor1'] = df1['actor1'].str.strip()
    update_a1 = update(df1.actor1, df_mov.set_index('itemID').itemIdx)
    df1['actor1'] = update_a1
    df1['actor2'] = df1['actor2'].values.astype(str)
    update_a2 = update(df1.actor2, df_mov.set_index('itemID').itemIdx)
    df1['actor2'] = update_a2
    df1['actor3'] = df1['actor3'].values.astype(str)
    update_a3 = update(df1.actor3, df_mov.set_index('itemID').itemIdx)
    df1['actor3'] = update_a3
    df1['actor4'] = df1['actor4'].values.astype(str)
    update_a4 = update(df1.actor4, df_mov.set_index('itemID').itemIdx)
    df1['actor4'] = update_a4
    df1['actor5'] = df1['actor5'].values.astype(str)
    update_a5 = update(df1.actor5, df_mov.set_index('itemID').itemIdx)
    df1['actor5'] = update_a5
    df1['actor6'] = df1['actor6'].values.astype(str)
    update_a6 = update(df1.actor6, df_mov.set_index('itemID').itemIdx)
    df1['actor6'] = update_a6
    df1['actor7'] = df1['actor7'].values.astype(str)
    update_a7 = update(df1.actor7, df_mov.set_index('itemID').itemIdx)
    df1['actor7'] = update_a7
    df1['actor8'] = df1['actor8'].values.astype(str)
    update_a8 = update(df1.actor8, df_mov.set_index('itemID').itemIdx)
    df1['actor8'] = update_a8
    df1['type1'] = df1['type1'].values.astype(str)
    update_t1 = update(df1.type1, df_mov.set_index('itemID').itemIdx)
    df1['type1'] = update_t1
    df1['type2'] = df1['type2'].values.astype(str)
    update_t2 = update(df1.type2, df_mov.set_index('itemID').itemIdx)
    df1['type2'] = update_t2
    df1['country'] = df1['country'].values.astype(str)
    update_c = update(df1.country, df_mov.set_index('itemID').itemIdx)
    df1['country'] = update_c
    df1['language'] = df1['language'].values.astype(str)
    update_l = update(df1.language, df_mov.set_index('itemID').itemIdx)
    df1['language'] = update_l
    # score just for mov_msc
    df1['score'].astype(str)
    df1['score'] = df1['score'].str.strip()
    update_s = update(df1.score, df_mov.set_index('itemID').itemIdx)
    df1['score'] = update_s

    data = df1.values.astype(int)
    data=np.maximum(data, 0)
    with open('../data/movie/' + 'movie_index.pkl', 'wb') as f_t:
        pickle.dump(data, f_t, pickle.HIGHEST_PROTOCOL)

    return data

# 将book领域item编码为multi-hot向量
def bok_fea_value():
    df = pd.read_csv('../data/book/book.csv', sep='|')
    df_bok = pd.read_csv('../data/book/book_feature_id.csv', sep=',')
    df1 = df.drop(['itemID'], axis=1)
    df1['writer'] = df1['writer'].str.strip()
    update_w = update(df1.writer, df_bok.set_index('itemID').itemIdx)
    df1['writer'] = update_w
    df1['publish'] = df1['publish'].str.strip()
    update_p = update(df1.publish, df_bok.set_index('itemID').itemIdx)
    df1['publish'] = update_p
    df1['translator'] = df1['translator'].str.strip()
    update_t = update(df1.translator, df_bok.set_index('itemID').itemIdx)
    df1['translator'] = update_t
    df1['score'] = df1['score'].str.strip()
    update_s = update(df1.score, df_bok.set_index('itemID').itemIdx)
    df1['score'] = update_s
    data = df1.values.astype(int)
    # data_graph = df1.values.astype(int)
    with open('../data/book/' + 'book_index.pkl', 'wb') as f_t:
        pickle.dump(data, f_t, pickle.HIGHEST_PROTOCOL)

    return data

# 将music领域item编码为multi-hot向量
def msc_fea_value():
    df = pd.read_csv('../data/music/music.csv', sep='|')
    df_msc = pd.read_csv('../data/music/music_feature_id.csv', sep=',')
    df1 = df.drop(['itemID'], axis=1)
    df1['player'].astype(str)
    df1['player'] = df1['player'].str.strip()
    update_p = update(df1.player, df_msc.set_index('itemID').itemIdx)
    df1['player'] = update_p
    df1['genre'].astype(str)
    df1['genre'] = df1['genre'].str.strip()
    update_g = update(df1.genre, df_msc.set_index('itemID').itemIdx)
    df1['genre'] = update_g
    df1['album'].astype(str)
    df1['album'] = df1['album'].str.strip()
    update_a = update(df1.album, df_msc.set_index('itemID').itemIdx)
    df1['album'] = update_a
    df1['media'].astype(str)
    df1['media'] = df1['media'].str.strip()
    update_m = update(df1.media, df_msc.set_index('itemID').itemIdx)
    df1['media'] = update_m
    df1['publisher'].astype(str)
    df1['publisher'] = df1['publisher'].str.strip()
    update_pu = update(df1.publisher, df_msc.set_index('itemID').itemIdx)
    df1['publisher'] = update_pu
    df1['score'].astype(str)
    df1['score'] = df1['score'].str.strip()
    update_s = update(df1.score, df_msc.set_index('itemID').itemIdx)
    df1['score'] = update_s
    data = df1.values.astype(int)
    data = np.maximum(data, 0)
    with open('../data/music/' + 'music_index.pkl', 'wb') as f_t:
        pickle.dump(data, f_t, pickle.HIGHEST_PROTOCOL)
    return data

#划分训练集、验证集、测试集
def train_validate_test_split():
    user_all = pd.read_csv('../data/records/user.csv', sep='\n')['UserID'].tolist()
    user_mov, user_bok, user_msc = user_item_interaction()
    item_all_mov = pd.read_csv('../data/movie/movie.csv', sep='|')['itemID'].tolist()  # 得到所有item的ID集合
    item_all_bok = pd.read_csv('../data/book/book.csv', sep='|')['itemID'].tolist()
    item_all_msc = pd.read_csv('../data/music/music.csv', sep='|')['itemID'].tolist()

    item_train_sample = []  # 所有user的训练集样本
    item_validate_sample = []  # 所有user的验证集样本
    item_test_sample = []  # 所有user的测试集样本
    # movie数据集训练、验证、测试集样本划分
    for u_id in user_all:
        u_mov, u_bok, u_msc = [], [], []
        u_mov_sample, u_bok_sample, u_msc_sample = [], [], []
        u_sample = []

        # 构造movie 中的样本数据
        indices_u_mov = np.nonzero(user_mov[u_id])
        u_mov.append(indices_u_mov[1:])
        item_all_n_mov = list(set(item_all_mov) - set(indices_u_mov[1]))
        for i in u_mov[0][0]:
            u_hist = np.delete(u_mov[0][0], np.where(u_mov[0][0] == i))
            u_mov_sample.append([i, u_hist])

        # 构造book 中的样本数据
        indices_u_bok = np.nonzero(user_bok[u_id])
        u_bok.append(indices_u_bok[1:])
        item_all_n_bok = list(set(item_all_bok) - set(indices_u_bok[1]))
        for i in u_bok[0][0]:
            u_hist = np.delete(u_bok[0][0], np.where(u_bok[0][0] == i))
            u_bok_sample.append([i, u_hist])

        # 构造music 中的样本数据
        indices_u_msc = np.nonzero(user_msc[u_id])
        u_msc.append(indices_u_msc[1:])
        item_all_n_msc = list(set(item_all_msc) - set(indices_u_msc[1]))
        for i in u_msc[0][0]:
            u_hist = np.delete(u_msc[0][0], np.where(u_msc[0][0] == i))
            u_msc_sample.append([i, u_hist])

        # 组织完整的训练数据样本
        for i in u_mov_sample:
            u_sample_i = []
            u_b = choice(u_bok_sample)
            u_mc = choice(u_msc_sample)
            u_sample_i.append([u_id, i, u_b, u_mc])
            if u_sample_i not in u_sample:
                u_sample.append([u_sample_i])
        # print(" 样本全集长度: %d" % len(u_sample[0]))
        # print(u_sample[0][1][0][2][0])
        for i in u_bok_sample:
            u_sample_i = []
            u_m = choice(u_mov_sample)
            u_mc = choice(u_msc_sample)
            u_sample_i.append([u_id, u_m, i, u_mc])
            if u_sample_i not in u_sample:
                u_sample.append([u_sample_i])

        for i in u_msc_sample:
            u_sample_i = []
            u_m = choice(u_mov_sample)
            u_b = choice(u_bok_sample)
            u_sample_i.append([u_id, u_m, u_b, i])
            if u_sample_i not in u_sample:
                u_sample.append([u_sample_i])
        # print(" 样本全集长度: %d" % len(u_sample))
        #print(u_sample)
        # u_train_validate, u_test, u_train, u_validate = [], [], [], []
        u_sample_id = list(range(len(u_sample)))
        u_train_validate_id = sample(u_sample_id, math.floor(0.8 * len(u_sample)))
        u_test_id = set(u_sample_id)-set(u_train_validate_id)
        u_train_validate = [u_sample[i] for i in u_train_validate_id]
        u_test = [u_sample[i] for i in u_test_id]
        u_train_id = sample(u_train_validate_id, math.floor(0.9 * len(u_train_validate)))
        u_validate_id = set(u_train_validate_id) - set(u_train_id)
        u_train = [u_sample[i] for i in u_train_id]
        u_validate = [u_sample[i] for i in u_validate_id]
        # print(" 训练数据: %d" % len(u_train))
        for u_p in u_train:
            j_m = choice(item_all_n_mov)
            j_b = choice(item_all_n_bok)
            j_mc = choice(item_all_n_msc)
            u_n = [u_id, j_m, u_p[0][0][1][1], j_b, u_p[0][0][2][1], j_mc, u_p[0][0][3][1]]
            item_train_sample.append([u_p, u_n])

        # print('训练样本：{}'.format(len(item_train_sample)))
        for u_p in u_validate:
            u_n = []
            for i in range(9):  # 对验证集每一个正样本采样负样本的条数
                j_m = choice(item_all_n_mov)
                j_b = choice(item_all_n_bok)
                j_mc = choice(item_all_n_msc)
                u_n = [u_id, j_m, u_p[0][0][1][1], j_b, u_p[0][0][2][1], j_mc, u_p[0][0][3][1]]
            item_validate_sample.append([u_p, u_n])
        # print('验证样本：{}'.format(len(item_validate_sample)))

        for u_p in u_test:
            u_n = []
            for i in range(9):  # 对测试集每一个正样本采样负样本的条数
                j_m = choice(item_all_n_mov)
                j_b = choice(item_all_n_bok)
                j_mc = choice(item_all_n_msc)
                u_n = [u_id, j_m, u_p[0][0][1][1], j_b, u_p[0][0][2][1], j_mc, u_p[0][0][3][1]]
            item_test_sample.append([u_p, u_n])
        # print('测试样本：{}'.format(len(item_test_sample)))

    # 将划分好的训练集、验证集和测试集存为文件
    with open('../data/records/' + 'train.pkl', 'wb') as f_t:
        pickle.dump(item_train_sample, f_t, pickle.HIGHEST_PROTOCOL)
    with open('../data/records/' + 'validate.pkl', 'wb') as f_v:
        pickle.dump(item_validate_sample, f_v, pickle.HIGHEST_PROTOCOL)
    with open('../data/records/' + 'test.pkl', 'wb') as f_tt:
        pickle.dump(item_test_sample, f_tt, pickle.HIGHEST_PROTOCOL)


# 通过用户ID索引每位用户交互的item索引，通过item索引取出用户交过的item multi-hot向量
def item_Feature(data):
    with open('../data_three/records/user_index.pkl', 'rb') as f:
        users = pickle.load(f)
    with open('../data_three/movie/movie_index.pkl', 'rb') as f:
        data_mov = pickle.load(f)
    with open('../data_three/book/book_index.pkl', 'rb') as f:
        data_bok = pickle.load(f)
    with open('../data_three/music/music_index.pkl', 'rb') as f:
        data_msc = pickle.load(f)
    u_i_sample_feature = []
    for j in range(len(data)):
        # 样本中各部分数据检索数据特征
        u_feature = users[data[j][0]]
        #  取movie样本特征
        mov_i = data_mov[data[j][1]]
        mov_hist = data_mov.take(data[j][2], axis=0)

        #  取book样本特征
        bok_i = data_bok[data[j][3]]
        bok_hist = data_bok.take(data[j][4], axis=0)

        #  取music样本特征
        msc_i = data_msc[data[j][5]]
        msc_hist = data_msc.take(data[j][6], axis=0)

        mov_n = data_mov[data[j][8]]
        bok_n = data_bok[data[j][10]]
        msc_n = data_msc[data[j][12]]

        u_i_sample_feature.append(
            [u_feature, mov_i, mov_hist, bok_i, bok_hist, msc_i, msc_hist, u_feature, mov_n, mov_hist, bok_n, bok_hist,
             msc_n, msc_hist])

    return u_i_sample_feature


def train_sample(j):
    # 重新组织训练集数据输入格式 multi_hot编码
    sample = []
    # for i in range(len(train)):
    for i in j:
        u_positive = [i[0][0][0][0], i[0][0][0][1][0], i[0][0][0][1][1], i[0][0][0][2][0],
                      i[0][0][0][2][1], i[0][0][0][3][0], i[0][0][0][3][1]]
        # print('正样本：test[0]={}'.format(u_positive))
        u_negtive = i[1]
        # 获取数据特征
        # u_pos = item_Feature(u_positive)
        # u_neg = item_Feature(u_negtive)
        sample.append([u_positive, u_negtive])

    return sample


def validate_test_sample(m):
    with open('../data_three/records/user_index.pkl', 'rb') as f:
        users = pickle.load(f)
    with open('../data_three/movie/movie_index.pkl', 'rb') as f:
        data_mov = pickle.load(f)
    with open('../data_three/book/book_index.pkl', 'rb') as f:
        data_bok = pickle.load(f)
    with open('../data_three/music/music_index.pkl', 'rb') as f:
        data_msc = pickle.load(f)
    # 重新组织验证集、测试集数据输入格式 multi_hot编码
    sample = []
    # print('测试样本：test[0][0][0][0]={}'.format(test[0][0][0][0]))
    # u_positive = [m[0][0][0][0], m[0][0][0][1][0], m[0][0][0][1][1], m[0][0][0][2][0],
    #               m[0][0][0][2][1]]
    u_feature = users[m[0][0][0][0]]
    #  取movie样本特征
    mov_i = data_mov[m[0][0][0][1][0]]
    mov_hist = data_mov.take(m[0][0][0][1][1], axis=0)

    #  取book样本特征
    bok_i = data_bok[m[0][0][0][2][0]]
    bok_hist = data_bok.take(m[0][0][0][2][1], axis=0)

    #  取music样本特征
    msc_i = data_msc[m[0][0][0][3][0]]
    msc_hist = data_msc.take(m[0][0][0][3][1], axis=0)
    u_pos = [u_feature, mov_i, mov_hist, bok_i, bok_hist, msc_i, msc_hist]
    u_neg = []
    for j in m[1]:
        u_feature = users[j[0]]
        #  取movie样本特征
        mov_i = data_mov[j[1]]
        mov_hist = data_mov.take(j[2], axis=0)

        #  取book样本特征
        bok_i = data_bok[j[3]]
        bok_hist = data_bok.take(j[4], axis=0)

        #  取book样本特征
        msc_i = data_msc[j[5]]
        msc_hist = data_msc.take(j[6], axis=0)

        u_neg.append([u_feature, mov_i, mov_hist, bok_i, bok_hist, msc_i, msc_hist])
    sample.append([u_pos, u_neg])
    return sample

# 填充数据
def processing_data(train):

    data_train = train_sample(train)
    length_mov, length_bok, length_msc = 240, 128, 141
    # d_m = len(data_train[0][0][1])
    # d_b = len(data_train[0][0][3])
    X_train =[]
    for j in range(len(data_train)):
        U_P = data_train[j][0][0]
        I_mov_P = data_train[j][0][1]
        if len(data_train[j][0][2]) < length_mov:
            mov = data_train[j][0][2].tolist()
            mov.extend([14809] * (length_mov - len(data_train[j][0][2])))
            data_train[j][0][2] = np.array(mov)
        M_mov_P = data_train[j][0][2]
        I_bok_P = data_train[j][0][3]
        if len(data_train[j][0][4]) < length_bok:
            bok = data_train[j][0][4].tolist()
            bok.extend([11136] * (length_bok - len(data_train[j][0][4])))
            data_train[j][0][4] = np.array(bok)
        B_bok_P = data_train[j][0][4]

        I_msc_P = data_train[j][0][5]
        if len(data_train[j][0][6]) < length_msc:
            msc = data_train[j][0][6].tolist()
            msc.extend([11123] * (length_msc - len(data_train[j][0][6])))
            data_train[j][0][6] = np.array(msc)
        MC_msc_P = data_train[j][0][6]

        # 负样本j[1]：
        I_mov_N = data_train[j][1][1]
        I_bok_N = data_train[j][1][3]
        I_msc_N = data_train[j][1][5]
        X_train.append([U_P, I_mov_P, M_mov_P, I_bok_P, B_bok_P, I_msc_P, MC_msc_P, U_P, I_mov_N, M_mov_P, I_bok_N, B_bok_P, I_msc_N, MC_msc_P])
    # 将划分好的训练集、验证集和测试集存为文件
    with open('../data/records/' + 'train(12).pkl', 'wb') as f_t:
        pickle.dump(X_train, f_t, pickle.HIGHEST_PROTOCOL)
    print('数据处理完成！！！')

'''处理冷启动用户训练数据'''
# with open('../MDCSR/data_three/records/train(12).pkl', 'rb') as f:
#         train = pickle.load(f)
#         '''各领域填充长度'''
#         length_mov, length_bok, length_msc = 240, 128, 141
#         u_sample_id = list(range(len(train)))
#         samples = sample(u_sample_id, math.floor(len(train) * 0.3))
#         sap_mov_id = sample(samples, math.floor(len(samples) * 0.3))
#         sap_bok_id = sample(samples, math.floor(len(samples) * 0.3))
#         sap_msc_id = sample(samples, math.floor(len(samples) * 0.3))
#         train_id = set(u_sample_id) - set(samples)
#         sap_mov = [train[i] for i in sap_mov_id]
#         sap_bok = [train[i] for i in sap_bok_id]
#         sap_msc = [train[i] for i in sap_msc_id]
#         '''重新组织冷启动用户训练数据'''
#         train_sample = [train[i] for i in train_id]
#         '''去掉历史交互记录，作为冷启动用户'''
#         for i in range(len(sap_mov)):
#             sap_mov[i][2] = [14809] * (length_mov)
#             sap_mov[i][9] = [14809] * (length_mov)
#             train_sample.append(sap_mov[i])
#         for i in range(len(sap_bok)):
#             sap_bok[i][4] = [11136] * (length_bok)
#             sap_bok[i][11] = [11136] * (length_bok)
#             train_sample.append(sap_bok[i])
#         for i in range(len(sap_msc)):
#             sap_msc[i][6] = [11123] * (length_msc)
#             sap_msc[i][13] = [11123] * (length_msc)
#             train_sample.append(sap_msc[i])
#         print(len(train_sample))
#         with open('../MDCSR/data_three/records/' + 'train_sample.pkl', 'wb') as f_t:
#             pickle.dump(train_sample, f_t, pickle.HIGHEST_PROTOCOL)
#         print('数据处理完成！！！')

        #print('{},{},{},{},{},{}'.format(len(train[11][2]),len(train[11][4]),len(train[11][6]),len(train[11][9]),len(train[11][11]),len(train[11][13])))

'''处理冷启动用户验证和测试数据'''
# with open('../data_three/records/train(12).pkl', 'rb') as f:
#     test = pickle.load(f)
#     '''获取正样本'''
#     print('{},{},{}'.format(len(test[11][0][0][0][1][1]), len(test[11][0][0][0][2][1]), len(test[11][0][0][0][3][1])))
#     '''获取负样本'''
#     print('{},{},{}'.format(len(test[11][1][9][2]), len(test[11][1][9][4]), len(test[11][1][9][6])))
#     u_sample_id = list(range(len(test)))
#     samples = sample(u_sample_id, math.floor(len(test) * 0.3))
#     sap_mov_id = sample(samples, math.floor(len(samples) * 0.2))
#     sap_bok_id = sample(samples, math.floor(len(samples) * 0.2))
#     sap_msc_id = sample(samples, math.floor(len(samples) * 0.2))
#     train_id = set(u_sample_id) - set(samples)
#     sap_mov = [test[i] for i in sap_mov_id]
#     sap_bok = [test[i] for i in sap_bok_id]
#     sap_msc = [test[i] for i in sap_msc_id]
#     '''重新组织冷启动用户训练数据'''
#     test_sample = [test[i] for i in train_id]
#     '''去掉历史交互记录，作为冷启动用户'''
#     for i in range(len(sap_mov)):
#         length_mov = sap_mov[i][0][0][0][1][1]
#         sap_mov[i][0][0][0][1][1] = [14809] * (length_mov)
#         for j in range(99):
#             sap_mov[i][1][j][2] = [14809] * (length_mov)
#         test_sample.append(sap_mov[i])
#     for i in range(len(sap_bok)):
#         length_bok = len(sap_mov[i][0][0][0][2][1])
#         sap_bok[i][0][0][0][2][1] = [11136] * (length_bok)
#         for j in range(99):
#             sap_bok[i][1][j][4] = [11136] * (length_bok)
#         test_sample.append(sap_bok[i])
#     for i in range(len(sap_msc)):
#         length_msc = len(sap_mov[i][0][0][0][3][1])
#         sap_msc[i][0][0][0][3][1] = [11123] * (length_msc)
#         for j in range(99):
#             sap_msc[i][1][j][6] = [11123] * (length_msc)
#         test_sample.append(sap_msc[i])
#     print(len(test_sample))
#     with open('../data_three/records/' + 'test_sample.pkl', 'wb') as f_t:
#         pickle.dump(test_sample, f_t, pickle.HIGHEST_PROTOCOL)
#     print('数据处理完成！！！')


# 用户：data_train[j][0][0]
# movie：data_train[j][0][1]
# mov_hist：data_train[j][0][2]
# book：data_train[j][0][3]
# book_hist：data_train[j][0][4]








