import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F

class Attention_CDR(nn.Module):

    def __init__(self, latent_dim, map_dim, attn_dropout):
        super(Attention_CDR, self).__init__()
        self.map_dim = map_dim
        self.latent_dim = latent_dim
        self.dropout = nn.Dropout(attn_dropout)
        self.W_map = nn.Parameter(torch.Tensor(self.map_dim, self.latent_dim))
        self.b_map = nn.Parameter(torch.Tensor(self.map_dim, 1))
        self.a_map = nn.Parameter(torch.Tensor(1, self.map_dim))
        self.__init_weight__()

    def __init_weight__(self):
        init.xavier_normal_(self.W_map)
        init.xavier_normal_(self.b_map)
        init.xavier_normal_(self.a_map)

    def forward(self, Z_user):
        batch_size, number, latent_dim = Z_user.size()
        Z_user = Z_user.reshape(batch_size, latent_dim, number)
        embed = torch.matmul(self.a_map, torch.tanh(torch.matmul(self.W_map, Z_user) + self.b_map))
        attn = torch.softmax((torch.sum(embed, dim=1) + 1e-24), 1)
        attn = attn.unsqueeze(1).expand(batch_size, 1, number)
        user_pref = self.dropout(torch.sum(Z_user * attn, dim=2))

        return user_pref

# if __name__=='__main__':
#     x=torch.randn(10, 32, 40)
#     # input_dim_bok=32
#     map_dim=16
#     attn_dropout=0.1
#     latent_dim=32
#     # net1= Embedding_book(input_dim_bok,latent_dim )
#     # z1=net1(x)
#     # print(z1)
#     net=Attention_CDR(map_dim, latent_dim, attn_dropout)
#     z=net(x)
#     print(z)