import torch
import torch.nn as nn
import numpy as np
from tqdm import tqdm
from Model_MDCSR.Attenion import Attention_CDR
from Model_MDCSR.Encoder_decoder import AutoEncoder
from Model_MDCSR.Aggregation import Cross_aggregation
from Model_MDCSR.dataprocessing import item_Feature,validate_test_sample

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

class model(nn.Module):
    def __init__(self, input_mov_col, input_bok_col, input_msc_col, latent_dim, extra_dim, map_dim, attn_dropout, mov_hist_number, bok_hist_number, msc_hist_number, user_number, mov_fea_number, bok_fea_number, msc_fea_number, batch_size):
        super(model, self).__init__()
        self.batch_size = batch_size
        self.mov_fea_number = mov_fea_number  # item 初始各个特征取值个数
        self.bok_fea_number = bok_fea_number
        self.msc_fea_number = msc_fea_number
        self.attn_dropout = attn_dropout
        self.latent_dim = latent_dim
        self.user_number = user_number
        self.dropout = torch.nn.Dropout(self.attn_dropout)
        self.sigmoid = torch.nn.Sigmoid()
        self.Embedding_user = torch.nn.Embedding(self.user_number, self.latent_dim)
        self.Embedding_mov = torch.nn.Embedding(self.mov_fea_number, self.latent_dim)
        self.Embedding_bok = torch.nn.Embedding(self.bok_fea_number, self.latent_dim)
        self.Embedding_msc = torch.nn.Embedding(self.msc_fea_number, self.latent_dim)
        self.input_mov_col = input_mov_col
        self.input_bok_col = input_bok_col
        self.input_msc_col = input_msc_col
        self.extra_dim = extra_dim
        self.map_dim = map_dim
        self.mov_hist_number = mov_hist_number
        self.bok_hist_number = bok_hist_number
        self.msc_hist_number = msc_hist_number
        self.Linear_mov = torch.nn.Linear(self.input_mov_col * self.latent_dim, self.latent_dim)
        self.Linear_bok = torch.nn.Linear(self.input_bok_col * self.latent_dim, self.latent_dim)
        self.Linear_msc = torch.nn.Linear(self.input_msc_col * self.latent_dim, self.latent_dim)
        self.Attention_mov = Attention_CDR(self.latent_dim, self.map_dim, self.attn_dropout)
        self.Attention_bok = Attention_CDR(self.latent_dim, self.map_dim, self.attn_dropout)
        self.Attention_msc = Attention_CDR(self.latent_dim, self.map_dim, self.attn_dropout)
        self.AutoEncoder_mov = AutoEncoder(self.latent_dim, self.extra_dim, self.mov_hist_number)
        self.AutoEncoder_bok = AutoEncoder(self.latent_dim, self.extra_dim, self.bok_hist_number)
        self.AutoEncoder_msc = AutoEncoder(self.latent_dim, self.extra_dim, self.msc_hist_number)
        self.Cross_Aggregation = Cross_aggregation(self.latent_dim, self.extra_dim, self.batch_size)

    def forward(self, batch_size, u, i_mov, X_movie, i_bok, X_book, i_msc, X_music):
        X_movie = torch.from_numpy(np.array(X_movie)).type(torch.LongTensor).to(device=device)
        X_book = torch.from_numpy(np.array(X_book)).type(torch.LongTensor).to(device=device)
        X_music = torch.from_numpy(np.array(X_music)).type(torch.LongTensor).to(device=device)
        Z_mov = self.Embedding_mov(X_movie)
        Z_bok = self.Embedding_bok(X_book)
        Z_msc = self.Embedding_msc(X_music)
        Z_mov = torch.reshape(Z_mov, (batch_size, -1, self.input_mov_col * self.latent_dim))
        Z_bok = torch.reshape(Z_bok, (batch_size, -1, self.input_bok_col * self.latent_dim))
        Z_msc = torch.reshape(Z_msc, (batch_size, -1, self.input_msc_col * self.latent_dim))
        Z_mov = self.Linear_mov(Z_mov)
        Z_bok = self.Linear_bok(Z_bok)
        Z_msc = self.Linear_msc(Z_msc)
        u = torch.from_numpy(np.array(u)).type(torch.LongTensor).to(device=device)
        user_embedding = self.Embedding_user(u)
        i_mov = torch.from_numpy(i_mov).type(torch.LongTensor).to(device=device)
        i_bok = torch.from_numpy(i_bok).type(torch.LongTensor).to(device=device)
        i_msc = torch.from_numpy(i_msc).type(torch.LongTensor).to(device=device)
        e_mov_i = self.Embedding_mov(i_mov)
        e_bok_i = self.Embedding_bok(i_bok)
        e_msc_i = self.Embedding_msc(i_msc)
        e_mov_i = torch.reshape(e_mov_i, (batch_size, self.input_mov_col * self.latent_dim))
        e_bok_i = torch.reshape(e_bok_i, (batch_size, self.input_bok_col * self.latent_dim))
        e_msc_i = torch.reshape(e_msc_i, (batch_size, self.input_msc_col * self.latent_dim))
        e_mov_i = self.Linear_mov(e_mov_i)
        e_bok_i = self.Linear_bok(e_bok_i)
        e_msc_i = self.Linear_msc(e_msc_i)

        user_pref_mov = self.Attention_mov(Z_mov)
        user_pref_bok = self.Attention_bok(Z_bok)
        user_pref_msc = self.Attention_msc(Z_msc)
        encode_mov, decode_mov = self.AutoEncoder_mov(user_pref_mov)
        encode_bok, decode_bok = self.AutoEncoder_bok(user_pref_bok)
        encode_msc, decode_msc = self.AutoEncoder_msc(user_pref_msc)

        rating_mov, rating_bok, rating_msc = self.Cross_Aggregation(encode_mov, encode_bok, encode_msc, e_mov_i, e_bok_i, e_msc_i, user_embedding)

        return Z_mov, Z_bok, Z_msc, decode_mov, decode_bok, decode_msc, rating_mov, rating_bok, rating_msc


def NDCG(y_true, y_score, k):
    if y_true in y_score[:k]:
        y_score = y_score[:k].tolist()
        # print("0元素的位置:{}".format(y_score.index(y_true)))
        gain = 2 ** 1 - 1
        discounts = np.log2(y_score.index(y_true) + 2)
        ndcg = (gain / discounts)
        return ndcg
    else:
        ndcg = 0.0
        return ndcg

def Precision(y_true, y_score, k):
    if y_true in y_score[:k]:
        i = 1
        return i
    else:
        i = 0
        return i


class model_runner(object):
    def __init__(self, config):
        self.config = config
        self.model = model(input_mov_col=self.config['input_mov_col'], input_bok_col=self.config['input_bok_col'], input_msc_col=self.config['input_msc_col'], latent_dim=self.config['latent_dim'], extra_dim=self.config['extra_dim'],
                           map_dim=self.config['map_dim'], attn_dropout=self.config['attn_dropout'], mov_hist_number=self.config['mov_hist_number'], bok_hist_number=self.config['bok_hist_number'],
                           msc_hist_number=self.config['msc_hist_number'], user_number=self.config['user_number'], mov_fea_number=self.config['mov_fea_number'], bok_fea_number=self.config['bok_fea_number'],
                           msc_fea_number=self.config['msc_fea_number'], batch_size=self.config['batch_size'])
        self.model.to(device)
        # 将不同层的优化参数分别采用不同优化器优化
        self.optPrediction = torch.optim.Adam(
            [
                {'params': self.model.Cross_Aggregation.parameters()},
                {'params': self.model.Linear_mov.parameters()},
                {'params': self.model.Linear_bok.parameters()},
                {'params': self.model.Linear_msc.parameters()},
                {'params': self.model.Embedding_mov.parameters()},
                {'params': self.model.Embedding_bok.parameters()},
                {'params': self.model.Embedding_msc.parameters()},
            ], lr=config['lr'],  weight_decay=0.001
        )

        self.optAutoEncoder_decoder_mov = torch.optim.Adam(
            [
                {'params': self.model.AutoEncoder_mov.parameters()},
                {'params': self.model.Attention_mov.parameters()},
            ], lr=config['lr'],  weight_decay=0.001
        )
        self.optAutoEncoder_decoder_bok = torch.optim.Adam(
            [
                {'params': self.model.AutoEncoder_bok.parameters()},
                {'params': self.model.Attention_bok.parameters()},
            ], lr=config['lr'],  weight_decay=0.001
        )
        self.optAutoEncoder_decoder_msc = torch.optim.Adam(
            [
                {'params': self.model.AutoEncoder_msc.parameters()},
                {'params': self.model.Attention_msc.parameters()},
            ], lr=config['lr'],  weight_decay=0.001
        )

    def train_single_batch(self, batch_train):
        self.optPrediction.zero_grad()
        self.optAutoEncoder_decoder_mov.zero_grad()
        self.optAutoEncoder_decoder_bok.zero_grad()
        self.optAutoEncoder_decoder_msc.zero_grad()

        batch_train = item_Feature(batch_train)
        batch_size = len(batch_train)
        d_m = len(batch_train[0][1])
        d_b = len(batch_train[0][3])
        d_mc = len(batch_train[0][5])

        U_P, I_mov_P, M_mov_P, I_bok_P, B_bok_P, I_msc_P, M_msc_P = np.empty([0, 1], dtype=int), np.empty([0, d_m],
                                                                                                          dtype=int), np.empty(
            [0, d_m], dtype=int), np.empty([0, d_b], dtype=int), np.empty([0, d_b], dtype=int), np.empty([0, d_mc],
                                                                                                         dtype=int), np.empty(
            [0, d_mc], dtype=int)
        I_mov_N, I_bok_N, I_msc_N = np.empty([0, d_m], dtype=int), np.empty([0, d_b], dtype=int), np.empty([0, d_mc],
                                                                                                           dtype=int)

        for j in range(batch_size):
            U_P = np.concatenate([U_P, batch_train[j][0].reshape(1, -1)], axis=0)
            I_mov_P = np.concatenate([I_mov_P, batch_train[j][1].reshape(1, -1)], axis=0)
            M_mov_P = np.concatenate([M_mov_P, batch_train[j][2]], axis=0)
            I_bok_P = np.concatenate([I_bok_P, batch_train[j][3].reshape(1, -1)], axis=0)
            B_bok_P = np.concatenate([B_bok_P, batch_train[j][4]], axis=0)
            I_msc_P = np.concatenate([I_msc_P, batch_train[j][5].reshape(1, -1)], axis=0)
            M_msc_P = np.concatenate([M_msc_P, batch_train[j][6]], axis=0)

            # 负样本j[1]：
            I_mov_N = np.concatenate([I_mov_N, batch_train[j][8].reshape(1, -1)], axis=0)
            I_bok_N = np.concatenate([I_bok_N, batch_train[j][10].reshape(1, -1)], axis=0)
            I_msc_N = np.concatenate([I_msc_N, batch_train[j][12].reshape(1, -1)], axis=0)

        # # 正样本j[0]：
        M_mov_P = np.reshape(M_mov_P, (batch_size, -1, d_m))
        B_bok_P = np.reshape(B_bok_P, (batch_size, -1, d_b))
        M_msc_P = np.reshape(M_msc_P, (batch_size, -1, d_mc))
        Z_mov_i, Z_bok_i, Z_msc_i, decode_mov_i, decode_bok_i, decode_msc_i, rating_mov_i, rating_bok_i, rating_msc_i = self.model(batch_size, U_P, I_mov_P, M_mov_P, I_bok_P, B_bok_P, I_msc_P, M_msc_P)
        Z_mov_j, Z_bok_j, Z_msc_j, decode_mov_j, decode_bok_j, decode_msc_j, rating_mov_j, rating_bok_j, rating_msc_j = self.model(
            batch_size, U_P, I_mov_N, M_mov_P, I_bok_N, B_bok_P, I_msc_N, M_msc_P)

        # 自编码器损失
        loss_auto_mov = torch.norm(decode_mov_i - Z_mov_i) + torch.norm(decode_mov_j - Z_mov_j)
        loss_auto_bok = torch.norm(decode_bok_i - Z_bok_i) + torch.norm(decode_bok_j - Z_bok_j)
        loss_auto_msc = torch.norm(decode_msc_i - Z_msc_i) + torch.norm(decode_msc_j - Z_msc_j)
        # BPR预测损失
        loss_predict = -torch.sum(torch.log(torch.sigmoid(rating_mov_i - rating_mov_j) + 1e-24) +
                         torch.log(torch.sigmoid(rating_bok_i - rating_bok_j) + 1e-24) +
                                  torch.log(torch.sigmoid(rating_msc_i - rating_msc_j) + 1e-24))

        loss_auto_mov.backward(retain_graph=True)
        loss_auto_bok.backward(retain_graph=True)
        loss_auto_msc.backward(retain_graph=True)
        loss_predict.backward()

        self.optPrediction.step()
        self.optAutoEncoder_decoder_mov.step()
        self.optAutoEncoder_decoder_bok.step()
        self.optAutoEncoder_decoder_msc.step()

        loss_auto_mov_batch = loss_auto_mov.data.cpu().numpy()
        loss_auto_bok_batch = loss_auto_bok.data.cpu().numpy()
        loss_auto_msc_batch = loss_auto_msc.data.cpu().numpy()
        loss_predict_batch = loss_predict.data.cpu().numpy()

        return loss_auto_mov_batch, loss_auto_bok_batch, loss_auto_msc_batch, loss_predict_batch

    def train_single_epoch(self, train, config, epoch_id):
        self.model.train()
        np.random.shuffle(train)
        num_examples = len(train)
        loss_epoch = 0
        batch_size = config['batch_size']
        for i in tqdm(range(0, num_examples, batch_size)):
            batch_id = (i // batch_size) + 1
            batch_train = train[i: min(i + config['batch_size'], num_examples)]  # 矩阵化计算的batch
            loss_auto_mov_batch, loss_auto_bok_batch, loss_auto_msc_batch, loss_predict_batch = self.train_single_batch(batch_train)
            print('\nBatch number:{}  movie编码器损失：{}    book编码器损失：{}     music编码器损失：{}    跨域预测损失：{}'.format(batch_id,
                                                                           loss_auto_mov_batch, loss_auto_bok_batch, loss_auto_msc_batch, loss_predict_batch))

            loss_epoch = loss_predict_batch + loss_epoch
            # print("第{}个batch , batch loss:{}".format(i+1, loss_batch))

        loss_epoch_mean = loss_epoch / (num_examples // batch_size + 1)
        print("第{}个epoch , epoch loss:{}".format(epoch_id + 1, loss_epoch_mean))
        with open('../parameters/model_epoch_loss.txt', 'a+') as f:
            f.write("epoch {}: epoch loss:{}".format(epoch_id + 1, loss_epoch_mean) + '\n')
        return loss_epoch_mean

    def evaluate(self, data):
        self.model.eval()
        np.random.shuffle(data)
        m_ndcg_all_1, m_ndcg_all_5, m_ndcg_all_10, m_ndcg_all_20 = [], [], [], []
        b_ndcg_all_1, b_ndcg_all_5, b_ndcg_all_10, b_ndcg_all_20 = [], [], [], []
        mc_ndcg_all_1, mc_ndcg_all_5, mc_ndcg_all_10, mc_ndcg_all_20 = [], [], [], []
        m_prec_all_5, m_prec_all_10, m_prec_all_20 = [], [], []
        b_prec_all_5, b_prec_all_10, b_prec_all_20 = [], [], []
        mc_prec_all_5, mc_prec_all_10, mc_prec_all_20 = [], [], []
        for i in tqdm(range(len(data))):
            u = validate_test_sample(data[i])
            batch_size = 100
            d_m = len(u[0][0][1])
            d_b = len(u[0][0][3])
            d_mc = len(u[0][0][5])
            # 初始化空列表
            U_P, I_mov_P, M_mov_P, I_bok_P, B_bok_P, I_msc_P, M_msc_P = np.empty([0, 1], dtype=int), np.empty([0, d_m],
                                                                                                              dtype=int), np.empty(
                [0, d_m], dtype=int), np.empty([0, d_b], dtype=int), np.empty([0, d_b], dtype=int), np.empty([0, d_mc],
                                                                                                             dtype=int), np.empty(
                [0, d_mc], dtype=int)
            U_P = np.concatenate([U_P, np.array(u[0][0][0]).reshape(1, -1)], axis=0)
            I_mov_P = np.concatenate([I_mov_P, u[0][0][1].reshape(1, -1)], axis=0)
            M_mov_P = np.concatenate([M_mov_P, u[0][0][2]], axis=0)
            I_bok_P = np.concatenate([I_bok_P, u[0][0][3].reshape(1, -1)], axis=0)
            B_bok_P = np.concatenate([B_bok_P, u[0][0][4]], axis=0)
            I_msc_P = np.concatenate([I_msc_P, u[0][0][5].reshape(1, -1)], axis=0)
            M_msc_P = np.concatenate([M_msc_P, u[0][0][6]], axis=0)
            for k in u[0][1]:
                U_P = np.concatenate([U_P, np.array(k[0]).reshape(1, -1)], axis=0)
                I_mov_P = np.concatenate([I_mov_P, k[1].reshape(1, -1)], axis=0)
                M_mov_P = np.concatenate([M_mov_P, k[2]], axis=0)
                I_bok_P = np.concatenate([I_bok_P, k[3].reshape(1, -1)], axis=0)
                B_bok_P = np.concatenate([B_bok_P, k[4]], axis=0)
                I_msc_P = np.concatenate([I_msc_P, k[5].reshape(1, -1)], axis=0)
                M_msc_P = np.concatenate([M_msc_P, k[6]], axis=0)

            M_mov_P = np.reshape(M_mov_P, (batch_size, -1, d_m))
            B_bok_P = np.reshape(B_bok_P, (batch_size, -1, d_b))
            M_msc_P = np.reshape(M_msc_P, (batch_size, -1, d_mc))
            # 一条训练样本为一个batch：
            Z_mov_i, Z_bok_i, Z_msc_i, decode_mov_i, decode_bok_i, decode_msc_i, rating_mov_i, rating_bok_i, rating_msc_i = self.model(batch_size, U_P, I_mov_P, M_mov_P, I_bok_P, B_bok_P, I_msc_P, M_msc_P)
            rating_mov_i = rating_mov_i.squeeze(dim=1).detach().cpu().numpy()
            rating_bok_i = rating_bok_i.squeeze(dim=1).detach().cpu().numpy()
            rating_msc_i = rating_msc_i.squeeze(dim=1).detach().cpu().numpy()

            m_, m_Rank = torch.topk(torch.tensor(rating_mov_i), len(rating_mov_i), dim=0, largest=True, sorted=True)
            b_, b_Rank = torch.topk(torch.tensor(rating_bok_i), len(rating_bok_i), dim=0, largest=True, sorted=True)
            mc_, mc_Rank = torch.topk(torch.tensor(rating_msc_i), len(rating_msc_i), dim=0, largest=True, sorted=True)
            # NDCG @1、@5 、@10
            m_ndcg_1 = NDCG(0, m_Rank, 1)
            b_ndcg_1 = NDCG(0, b_Rank, 1)
            mc_ndcg_1 = NDCG(0, mc_Rank, 1)
            m_ndcg_all_1.append(m_ndcg_1)
            b_ndcg_all_1.append(b_ndcg_1)
            mc_ndcg_all_1.append(mc_ndcg_1)

            m_ndcg_5 = NDCG(0, m_Rank, 5)
            b_ndcg_5 = NDCG(0, b_Rank, 5)
            mc_ndcg_5 = NDCG(0, mc_Rank, 5)
            m_ndcg_all_5.append(m_ndcg_5)
            b_ndcg_all_5.append(b_ndcg_5)
            mc_ndcg_all_5.append(mc_ndcg_5)

            m_ndcg_10 = NDCG(0, m_Rank, 10)
            b_ndcg_10 = NDCG(0, b_Rank, 10)
            mc_ndcg_10 = NDCG(0, mc_Rank, 10)
            m_ndcg_all_10.append(m_ndcg_10)
            b_ndcg_all_10.append(b_ndcg_10)
            mc_ndcg_all_10.append(mc_ndcg_10)

            m_ndcg_20 = NDCG(0, m_Rank, 20)
            b_ndcg_20 = NDCG(0, b_Rank, 20)
            mc_ndcg_20 = NDCG(0, mc_Rank, 20)
            m_ndcg_all_20.append(m_ndcg_20)
            b_ndcg_all_20.append(b_ndcg_20)
            mc_ndcg_all_20.append(mc_ndcg_20)

            # precision @5、 @10
            m_prec_5 = Precision(0, m_Rank, 5)
            b_prec_5 = Precision(0, b_Rank, 5)
            mc_prec_5 = Precision(0, mc_Rank, 5)
            m_prec_all_5.append(m_prec_5)
            b_prec_all_5.append(b_prec_5)
            mc_prec_all_5.append(mc_prec_5)

            m_prec_10 = Precision(0, m_Rank, 10)
            b_prec_10 = Precision(0, b_Rank, 10)
            mc_prec_10 = Precision(0, mc_Rank, 10)
            m_prec_all_10.append(m_prec_10)
            b_prec_all_10.append(b_prec_10)
            mc_prec_all_10.append(mc_prec_10)

            m_prec_20 = Precision(0, m_Rank, 20)
            b_prec_20 = Precision(0, b_Rank, 20)
            mc_prec_20 = Precision(0, mc_Rank, 20)
            m_prec_all_20.append(m_prec_20)
            b_prec_all_20.append(b_prec_20)
            mc_prec_all_20.append(mc_prec_20)
            # 求各个指标平均值
        m_average_ndcg_1 = np.mean(m_ndcg_all_1)
        b_average_ndcg_1 = np.mean(b_ndcg_all_1)
        mc_average_ndcg_1 = np.mean(mc_ndcg_all_1)

        m_average_ndcg_5 = np.mean(m_ndcg_all_5)
        b_average_ndcg_5 = np.mean(b_ndcg_all_5)
        mc_average_ndcg_5 = np.mean(mc_ndcg_all_5)

        m_average_ndcg_10 = np.mean(m_ndcg_all_10)
        b_average_ndcg_10 = np.mean(b_ndcg_all_10)
        mc_average_ndcg_10 = np.mean(mc_ndcg_all_10)

        m_average_ndcg_20 = np.mean(m_ndcg_all_20)
        b_average_ndcg_20 = np.mean(b_ndcg_all_20)
        mc_average_ndcg_20 = np.mean(mc_ndcg_all_20)

        m_average_prec_5 = np.mean(m_prec_all_5)
        b_average_prec_5 = np.mean(b_prec_all_5)
        mc_average_prec_5 = np.mean(mc_prec_all_5)

        m_average_prec_10 = np.mean(m_prec_all_10)
        b_average_prec_10 = np.mean(b_prec_all_10)
        mc_average_prec_10 = np.mean(mc_prec_all_10)

        m_average_prec_20 = np.mean(m_prec_all_20)
        b_average_prec_20 = np.mean(b_prec_all_20)
        mc_average_prec_20 = np.mean(mc_prec_all_20)

        print(
            "[Movie evaluate:] NDCG@5={}, NDCG@10={}, NDCG@20={}, Precision@5={}, Precision@10={}, Precision@20={}".format(
                m_average_ndcg_5, m_average_ndcg_10, m_average_ndcg_20, m_average_prec_5,
                m_average_prec_10, m_average_prec_20))
        print(
            "[Book evaluate:] NDCG@5={}, NDCG@10={}, NDCG@20={}, Precision@5={}, Precision@10={}, Precision@20={}".format(
                b_average_ndcg_5, b_average_ndcg_10, b_average_ndcg_20, b_average_prec_5,
                b_average_prec_10, b_average_prec_20))
        print(
            "[Music evaluate:] NDCG@5={}, NDCG@10={}, NDCG@20={}, Precision@5={}, Precision@10={}, Precision@20={}".format(
                mc_average_ndcg_5, mc_average_ndcg_10, mc_average_ndcg_20, mc_average_prec_5,
                mc_average_prec_10, mc_average_prec_20))



