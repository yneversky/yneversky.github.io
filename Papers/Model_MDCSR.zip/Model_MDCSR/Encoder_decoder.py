import torch
import torch.nn as nn
import torch.nn.init as init

class AutoEncoder(nn.Module):
    def __init__(self, latent_dim, extra_dim, hist_number):
        super(AutoEncoder, self).__init__()
        self.latent_dim = latent_dim
        self.extra_dim = extra_dim
        self.hist_number = hist_number
        self.encoder = nn.Sequential(
            nn.Linear(self.latent_dim, self.extra_dim * self.latent_dim),
            nn.Tanh(),
            nn.Linear(self.extra_dim * self.latent_dim, 2 * self.latent_dim),
            nn.Tanh(),
            nn.Linear(2 * self.latent_dim, self.extra_dim)

        )

        self.decoder = nn.Sequential(
            nn.Linear(self.extra_dim, 2 * self.latent_dim),
            nn.Tanh(),
            nn.Linear(2 * self.latent_dim, self.extra_dim * self.latent_dim),
            nn.Tanh(),
            nn.Linear(self.extra_dim * self.latent_dim, self.latent_dim),
            nn.Sigmoid()
        )

    def forward(self, user_pref):
        batch_size, _ = user_pref.size()
        encode = self.encoder(user_pref)
        decoded = self.decoder(encode)
        decode = decoded.unsqueeze(2).expand(batch_size, self.latent_dim, self.hist_number)
        decode = decode.reshape(batch_size, self.hist_number, self.latent_dim)

        return encode, decode


