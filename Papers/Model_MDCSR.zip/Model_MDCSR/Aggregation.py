import torch
import torch.nn as nn
import torch.nn.init as init

class Cross_aggregation(nn.Module):
    def __init__(self, latent_dim, extra_dim, batch_size, domain=3):
        super(Cross_aggregation, self).__init__()
        self.latent_dim = latent_dim
        self.extra_dim = extra_dim
        self.domain = domain
        self.batch_size = batch_size
        self.W_proj = nn.Parameter(torch.Tensor(self.latent_dim, self.extra_dim))
        self.g_proj = nn.Parameter(torch.Tensor(self.domain, 1))
        self.MLP_mov = nn.Sequential(
            nn.Linear(3 * self.latent_dim, 2 * self.latent_dim),
            nn.Tanh(),
            nn.Linear(2 * self.latent_dim, self.latent_dim),
            nn.Tanh(),
            nn.Linear(self.latent_dim, 1),
            nn.Sigmoid()
        )
        self.MLP_bok = nn.Sequential(
            nn.Linear(3 * self.latent_dim, 2 * self.latent_dim),
            nn.Tanh(),
            nn.Linear(2 * self.latent_dim, self.latent_dim),
            nn.Tanh(),
            nn.Linear(self.latent_dim, 1),
            nn.Sigmoid()
        )
        self.MLP_msc = nn.Sequential(
            nn.Linear(3 * self.latent_dim, 2 * self.latent_dim),
            nn.Tanh(),
            nn.Linear(2 * self.latent_dim, self.latent_dim),
            nn.Tanh(),
            nn.Linear(self.latent_dim, 1),
            nn.Sigmoid()
        )
        self.__init__weight()

    def __init__weight(self):
        init.xavier_normal_(self.W_proj)
        init.xavier_normal_(self.g_proj)

    def forward(self, pref_mov, pref_bok, pref_msc, i_mov, i_bok, i_msc, embed_user):
        pref_user = torch.cat((pref_mov, pref_bok, pref_msc), dim=1)
        pref_user = pref_user.reshape(-1, self.extra_dim, self.domain)
        prefer_u = torch.squeeze(torch.matmul(torch.matmul(self.W_proj, pref_user), self.g_proj))
        embed_user = torch.squeeze(embed_user)
        rating_mov = self.MLP_mov(torch.cat([prefer_u, embed_user, i_mov], dim=1))
        rating_bok = self.MLP_bok(torch.cat([prefer_u, embed_user, i_bok], dim=1))
        rating_msc = self.MLP_msc(torch.cat([prefer_u, embed_user, i_msc], dim=1))

        return rating_mov, rating_bok, rating_msc

# if __name__=='__main__':
#     x1 = torch.randn(10, 16)
#     x2 = torch.randn(10, 16)
#     x3 = torch.randn(10, 16)
#     i1 = torch.randn(10,32)
#     i2 = torch.randn(10, 32)
#     i3 = torch.randn(10, 32)
#     u = torch.randn(10, 32)
#     # input_dim_bok=32
#     extra_dim=16
#     attn_dropout=0.1
#     latent_dim=32
#     # net1= Embedding_book(input_dim_bok,latent_dim )
#     # z1=net1(x)
#     # print(z1)
#     net=Cross_aggregation(latent_dim, extra_dim, 10)
#     z=net(x1, x2, x3, i1, i2, i3, u)
#     print(z)
