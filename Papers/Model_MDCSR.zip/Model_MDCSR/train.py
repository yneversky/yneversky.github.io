import argparse
import numpy as np
import torch
import pickle
from Model_MDCSR.model import model_runner

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
parser = argparse.ArgumentParser('MDCSR_model')

parser.add_argument('--epoch', type=int, default=50, help='number of Epoches')
parser.add_argument('--batch_size', type=int, default=300, help='batch_size')
parser.add_argument('--lr', type=float, default=0.001, help='learning rate')
parser.add_argument('--latent_dim', type=int, default=16, help='latent embedding dimension')
parser.add_argument('--extra_dim', type=int, default=8, help='extracted embedding dimension by AutoEncoder')
parser.add_argument('--map_dim', type=int, default=8, help='dimension of learned embedding through Attention Layer')
parser.add_argument('--attn_dropout', type=float, default=0.1, help='attention dropout rate')
parser.add_argument('--input_mov_col', type=int, default=16, help='column of movie item')
parser.add_argument('--input_bok_col', type=int, default=4, help='column of book item')
parser.add_argument('--input_msc_col', type=int, default=6, help='column of music item')
parser.add_argument('--mov_hist_number', type=int, default=240, help='the number of users interacted movies')
parser.add_argument('--bok_hist_number', type=int, default=128, help='the number of users interacted books')
parser.add_argument('--msc_hist_number', type=int, default=141, help='the number of users interacted musics')
parser.add_argument('--user_number', type=int, default=800, help='total user number')
parser.add_argument('--mov_fea_number', type=int, default=47462, help='total movie features number')
parser.add_argument('--bok_fea_number', type=int, default=8913, help='total book features number')
parser.add_argument('--msc_fea_number', type=int, default=8086, help='total music features number')

args=parser.parse_args()

MDCSR_config = {
              'epoch': args.epoch,
              'batch_size': args.batch_size,
              'lr': args.lr,
              'latent_dim': args.latent_dim,
              'extra_dim': args.extra_dim,
              'map_dim': args.map_dim,
              'attn_dropout': args.attn_dropout,
              'input_mov_col': args.input_mov_col,
              'input_bok_col': args.input_bok_col,
              'input_msc_col': args.input_msc_col,
              'mov_hist_number': args.mov_hist_number,
              'bok_hist_number': args.bok_hist_number,
              'msc_hist_number': args.msc_hist_number,
              'user_number': args.user_number,
              'mov_fea_number': args.mov_fea_number,
              'bok_fea_number': args.bok_fea_number,
              'msc_fea_number': args.msc_fea_number,
}


def SampleTrain():
    print("模型开始训练啦！")
    config = MDCSR_config
    model = model_runner(config)

    with open('../data_three/records/train_sample.pkl', 'rb') as f:
        train = pickle.load(f)
        # train = train_sample(path='../data_graph/item/train.pkl')
        min_loss = 100000
        i = 0
        print('开始训练：')
        for epoch in range(config['epoch']):
            print('Epoch {}  starts !!!'.format(epoch + 1))
            loss_epoch_mean = model.train_single_epoch(train, config, epoch_id=epoch)
            if loss_epoch_mean < min_loss:
                l = np.abs(loss_epoch_mean - min_loss)
                min_loss = loss_epoch_mean
                print("save model")
                torch.save(model.model.state_dict(), '../parameters/' + 'model_best' + '.pth')
                if l < 2:
                    i += 1
                    if i == 15:
                        break
        f.close()

    # 加载训练集上最好的模型参数用于验证
    model.model.load_state_dict(torch.load('../parameters/' + 'model_best' + '.pth'))
    print('开始验证啦 !!!')
    with open('../data_three/records/test.pkl', 'rb') as f:
        validate = pickle.load(f)
        model.evaluate(validate)
        f.close()

SampleTrain()